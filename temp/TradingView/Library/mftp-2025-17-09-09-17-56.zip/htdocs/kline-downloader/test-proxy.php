<?php

function getDailyJSON($url) {
    // Replace with your Webshare proxy list (from dashboard after signup)
    $proxies = [
        "halusngj:iqii2z5mv1ke@38.154.227.167:5868",
        // Add up to 10 from free tier
    ];
    $proxy = $proxies[array_rand($proxies)]; // Random proxy for IP rotation

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    // Split proxy and auth (InfinityFree might block this, test it)
    list($auth, $proxyHost) = explode('@', $proxy);
    curl_setopt($ch, CURLOPT_PROXY, $proxyHost);
    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $auth);

    $response = curl_exec($ch);

    if ($response === false) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['error' => true, 'message' => "cURL failed: $error", 'proxy' => $proxy];
    }

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode != 200) {
        return ['error' => true, 'message' => "HTTP Error: $httpCode", 'raw_response' => $response];
    }

    $json = json_decode($response, true);
    return $json ?: ['error' => true, 'message' => 'Invalid JSON', 'raw_response' => $response];
}

// Test IP rotation
$url = "https://api.ipify.org";
$result = getDailyJSON($url);

if (isset($result['error'])) {
    echo "Error: " . $result['message'] . "\n";
    if (isset($result['proxy'])) echo "Proxy: " . $result['proxy'] . "\n";
} else {
    echo "Your new IP: " . $result . "\n";
}