<?php
// MEGA public URL
$megaUrl = 'https://mega.nz/file/fVgUBSja#YGNKvcUPCrqxq5yPvFi2EjLsHhC4YNI0h5QAoGPSsak';

// Extract file ID and key
preg_match('/file\/(.+?)#(.+)/', $megaUrl, $matches);
$fileId = $matches[1]; // fVgUBSja
$fileKey = $matches[2]; // YGNKvcUPCrqxq5yPvFi2EjLsHhC4YNI0h5QAoGPSsak

// Decode the base64 key (URL-safe base64)
$fileKey = str_replace(['-', '_'], ['+', '/'], $fileKey);
$fileKey = base64_decode($fileKey);

// MEGA API endpoint
$apiUrl = 'https://g.api.mega.co.nz/cs?id=' . rand(10000, 99999);

// API request payload
$payload = json_encode([[
    'a' => 'g',
    'p' => $fileId,
    'g' => 1
]]);

// Get download link
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'User-Agent: Mozilla/5.0'
]);

$response = curl_exec($ch);
if ($response === false) {
    die('API cURL Error: ' . curl_error($ch));
}
curl_close($ch);

$data = json_decode($response, true);
if (!isset($data[0]['g'])) {
    echo 'API Response: ' . $response . "\n";
    die('Error: Could not get download link.');
}

$downloadUrl = $data[0]['g'];

// Fetch encrypted file content
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $downloadUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$encryptedContent = curl_exec($ch);

if ($encryptedContent === false) {
    die('Download cURL Error: ' . curl_error($ch));
}
curl_close($ch);

// Decrypt the content (AES-128-CBC, assuming key length matches)
$iv = substr($fileKey, 16, 16); // Last 16 bytes of key as IV
$key = substr($fileKey, 0, 16); // First 16 bytes as key
$fileContent = openssl_decrypt($encryptedContent, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);

if ($fileContent === false) {
    file_put_contents('encrypted.bin', $encryptedContent);
    die('Error: Decryption failed. Check encrypted.bin.');
}

// Verify it’s a PNG
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->buffer($fileContent);
if ($mimeType !== 'image/png') {
    file_put_contents('decrypted.bin', $fileContent);
    die("Error: Expected PNG, got $mimeType. Check decrypted.bin.");
}

// Convert to Base64
$base64Data = base64_encode($fileContent);
$dataUrl = "data:image/png;base64,$base64Data";

echo "Base64 Data URL: $dataUrl\n";
?>
<!DOCTYPE html>
<html>
<head>
    <title>MEGA PNG Image</title>
</head>
<body>
    <img src="<?php echo $dataUrl; ?>" alt="MEGA PNG Image">
</body>
</html>